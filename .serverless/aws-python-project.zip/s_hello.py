import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='darrenrabbs',
    application_name='aws-python-project',
    app_uid='gdyMt1PDHxyxMHLXpl',
    org_uid='c1ea86d7-3c92-4366-8403-bdd81094d3b1',
    deployment_uid='f05a7d09-8529-4919-b80e-215e8d3afdc9',
    service_name='aws-python-project',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='6.2.3',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'aws-python-project-dev-hello', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('handler.hello')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
